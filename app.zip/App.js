import React, { Component } from 'react';
import { View, WebView, StatusBar } from 'react-native';

export default class App extends Component {
    render() {

        var webViewCode = `
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script type="text/javascript" src="https://static.codehs.com/gulp/89cd3118fd3b4fab9f913ce7091f1761944163e8/chs-js-lib/chs.js"></script>

<style>
    body, html {
        margin: 0;
        padding: 0;
    }
    canvas {
        margin: 0px;
        padding: 0px;
        display: inline-block;
        vertical-align: top;
    }
    #btn-container {
        text-align: center;
        padding-top: 10px;
    }
    #btn-play {
        background-color: #8cc63e;
    }
    #btn-stop {
        background-color: #de5844;
    }
    .glyphicon {
        margin-top: -3px;
        color: #FFFFFF;
    }
</style>
</head>

<body>
    <div id="canvas-container" style="margin: 0 auto; ">
        <canvas
        id="game"
        width="400"
        height="480"
        class="codehs-editor-canvas"
        style="width: 100%; height: 100%; margin: 0 auto;"
        ></canvas>
    </div>
    <div id="console"></div>
    <div id="btn-container">
        <button class="btn btn-main btn-lg" id="btn-play" onclick='stopProgram(); runProgram();'><span class="glyphicon glyphicon-play" aria-hidden="true"></span></button>
        <button class="btn btn-main btn-lg" id="btn-stop" onclick='stopProgram();'><span class="glyphicon glyphicon-stop" aria-hidden="true"></span></button>
    </div>

<script>
    var console = {};
    console.log = function(msg){
        $("#console").html($("#console").html() + "     " + msg);
    };

    var runProgram = function() {
        var t = 0;
var W =  getWidth()/2;
var H = getHeight()-50;
var time = t; //this is the variable t for time which increases with the time function and is labled time for the reader of the code to be able to comprehend the code better 
var radius = 10;    //radius of the ball 
var level = readInt("What level would you like to throw at? (1-5) "); // some bonk gang stuff boi cant touch dis
while(level > 5 || level <= 0){ // put the while loop in there so you can ony choose one through five
    var level = readInt("What level would you like to throw at? (1-5) "); // changes the height of the position of launch 
}
    if(level == 5 ){
        println("You have chosen level Five! ");
        var height = 0 + radius * 2 ;
    }
    if(level == 4 ){
        println("You have chosen level Four! ");
        var height = getHeight() * 1/4 ;
    }
    if(level == 3 ){
        println("You have chosen level Three! ");
        var height = getHeight() * 1/2 ;
    }
    if(level == 2 ){
        println("You have chosen level Two! ");
        var height = getHeight() * 3/4 ;
    }
    if(level == 1 ){
        println("You have chosen level One! ");
        var height = getHeight() - 4* radius;
    }
var width = 50;  //width will be standard to show that the projectile is launched from a standard x value
var line = new Line(width, getHeight(), width, height);
var line1 = new Line(0, height, width, height);
// the "lines" are the place where the ball is projected from 
var projectile = new Circle(radius);  // this is the projectile, projectile will always be a ball and air resistance is negligible
projectile.setColor("ORANGE");
projectile.setPosition(width,height - radius);  // position the ball is set at width and height of the building so the ball is on the edge just before is it projected into the air and will move according to the laws of physics 
var target = new Rectangle(50, 10);  // this is the target that you have to hit 
target.setPosition(W , getHeight()-10); // position of the target
target.setColor("Orange");
add(target);

var radius = projectile.getRadius();
var degrees = readInt ("What is the angle of projection in degress "); // angle of projection
var pi = 3.14159265359; // pi because math.pi is superfluous and inaccurate 
var vi = readInt("What is the initial velocity (1-10) "); // asks the pleb for the speed 
 
//because javameasures cos sin etc in  pi radians the measurements are converted 0into degress
var sin = Math.sin(degrees * pi/180); 
var viY = vi * sin; // vertical component of of speed
var cos = Math.cos(degrees * pi/180);
var viX = vi * cos; // horizontal component of the speed
println("Vertical component of projectile motion = " + viY); //shows the components 
println("Horizontal component of projectile motion = " + viX);
// the total y component will be divided by 1000 because the value of time is increaseing at the rate of 1000
add(line);
add(line1);
add(projectile);

var win = new Text("YOU HAVE WON", "30pt Arial");
win.setColor(Color.GREEN);
win.setPosition(55 , getHeight()/2);
var lose = new Text("YOU HAVE LOST", "30pt Arial");
lose.setColor(Color.RED);
lose.setPosition(55 , getHeight()/2);

var xPos = projectile.getX(); // x position on tje graph 
var yPos = projectile.getY(); // y position on the graph

function move(){
    // this is the movement of the projectile taking into account the angle of projection \
    // according the graph the ball moves down with positive numbers and moves up with negative numbers 
    var acceleration = 2 * Math.pow(t,2);
    projectile.move( viX/2 , - viY/2  + acceleration/1000  );
    println(projectile.getX() + " x position ");
    var xPos = projectile.getX();
    var yPos = projectile.getY();
    println(yPos + " Y position ");
    if(yPos >= 460 ){
        stopTimer(move);
        if(xPos <= W + 40 + radius && xPos >= W - radius){
            add(win);
            projectile.setColor("green");
            target.setColor("green");
        }else{
            add(lose); //tells you thta you lost and need to improve your skills
            projectile.setColor("red");
            target.setColor("red");
        }
    }
}
    // this is the function of time that increases 
function Time(){
    var acceleration = 4.905 * Math.pow(t,2);  // the total y component will be divided by 1000 because the value of time is increaseing at the rate of 1000
    t++;  // adds time 
}
function start(){
    setTimer(Time, 1); //increases time
    setTimer(move,1);  //moves 
}


        if (typeof start === 'function') {
            start();
        }

        // Overrides setSize() if called from the user's code. Needed because
        // we have to change the canvas size and attributes to reflect the
        // user's desired program size. Calling setSize() from user code only
        // has an effect if Fit to Full Screen is Off. If Fit to Full Screen is
        // On, then setSize() does nothing.
        function setSize(width, height) {
            if (!true) {
                // Call original graphics setSize()
                window.__graphics__.setSize(width, height);

                // Scale to screen width but keep aspect ratio of program
                // Subtract 2 to allow for border
                var canvasWidth = window.innerWidth - 2;
                var canvasHeight = canvasWidth * getHeight() / getWidth();

                // Make canvas reflect desired size set
                adjustMarginTop(canvasHeight);
                setCanvasContainerSize(canvasWidth, canvasHeight);
                setCanvasAttributes(canvasWidth, canvasHeight);
            }
        }
    };

    var stopProgram = function() {
        removeAll();
        window.__graphics__.fullReset();
    }

    window.onload = function() {
        if (!false) {
            $('#btn-container').remove();
        }

        var canvasWidth;
        var canvasHeight;
        if (true) {
            // Get device window width and set program size to those dimensions
            setSize(window.innerWidth, window.innerHeight);
            canvasWidth = getWidth();
            canvasHeight = getHeight();

            if (false) {
                // Make room for buttons if being shown
                $('#btn-container').css('padding', '5px 0');
                canvasHeight -= $('#btn-container').outerHeight();
            }

            setCanvasAttributes(canvasWidth, canvasHeight);
        } else {
            // Scale to screen width but keep aspect ratio of program
            // Subtract 2 to allow for border
            canvasWidth = window.innerWidth - 2;
            canvasHeight = canvasWidth * getHeight() / getWidth();

            // Light border around canvas if not full screen
            $('#canvas-container').css('border', '1px solid #beccd4');

            adjustMarginTop(canvasHeight);
        }

        setCanvasContainerSize(canvasWidth, canvasHeight);

        if (true) {
            runProgram();
        }
    };

    // Set the canvas container width and height.
    function setCanvasContainerSize(width, height) {
        $('#canvas-container').width(width);
        $('#canvas-container').height(height);
    }

    // Set the width and height attributes of the canvas. Allows
    // getTouchCoordinates to sense x and y correctly.
    function setCanvasAttributes(canvasWidth, canvasHeight) {
        $('#game').attr('width', canvasWidth);
        $('#game').attr('height', canvasHeight);
    }

    // Assumes the Fit to Full Screen setting is Off. Adjusts the top margin
    // depending on the Show Play/Stop Buttons setting.
    function adjustMarginTop(canvasHeight) {
        var marginTop = (window.innerHeight - canvasHeight)/2;
        if (false) {
            marginTop -= $('#btn-container').height()/3;
        }
        $('#canvas-container').css('margin-top', marginTop);
    }
</script>
</body>
</html>
`;
        return (
            <View style={{ flex: 1 }}>
                <StatusBar hidden />
                <WebView
                    source={{html: webViewCode, baseUrl: "/"}}
                    javaScriptEnabled={true}
                    style={{ flex: 1 }}
                    scrollEnabled={false}
                    bounces={false}
                    scalesPageToFit={false}
                ></WebView>
            </View>
        );
    }
}
